# SMTP Warmup

Warm up an SMTP source with randomized, industry-tailored content, capture
inbound replies/bounces, and generate HTML + CSV reports with per-gateway and
per-domain deliverability.

## Setup

```bash
npm install
cp .env.example .env       # fill in defaults (optional)
npm start