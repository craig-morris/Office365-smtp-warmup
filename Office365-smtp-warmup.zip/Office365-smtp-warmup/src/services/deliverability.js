const dns = require('dns').promises;

const GATEWAYS = [
  { name: 'Microsoft 365 (EOP)', re: /\.mail\.protection\.outlook\.com$/i },
  { name: 'Google Workspace',    re: /\.google\.com$|\.googlemail\.com$/i },
  { name: 'Proofpoint',          re: /\.pphosted\.com$|proofpoint/i },
  { name: 'Mimecast',            re: /\.mimecast\.com$/i },
  { name: 'Barracuda',           re: /\.barracudanetworks\.com$/i },
  { name: 'Cisco IronPort',      re: /\.iphmx\.com$|\.ironport\./i },
  { name: 'Zoho',                re: /\.zoho\./i },
  { name: 'Amazon SES',          re: /\.amazonses\.com$/i },
  { name: 'SendGrid',            re: /\.sendgrid\.net$/i },
  { name: 'Mailgun',             re: /\.mailgun\.org$/i },
];

// Process-lifetime cache: domain -> Promise<{gateway, mx}>
const mxCache = new Map();

async function resolveOne(domain) {
  try {
    const mx = await dns.resolveMx(domain);
    if (!mx.length) return { gateway: 'No MX', mx: null };
    const sorted = mx.sort((a, b) => a.priority - b.priority);
    for (const rec of sorted) {
      for (const g of GATEWAYS) {
        if (g.re.test(rec.exchange)) return { gateway: g.name, mx: rec.exchange };
      }
    }
    return { gateway: 'Other', mx: sorted[0].exchange };
  } catch (e) {
    return { gateway: 'Unknown', mx: null, error: e.code || e.message };
  }
}

function resolveGateway(domain) {
  if (mxCache.has(domain)) return mxCache.get(domain);
  const p = resolveOne(domain);
  mxCache.set(domain, p);
  return p;
}

/** Pre-warm cache for all unique domains in parallel (bounded). */
async function prewarm(domains, concurrency = 32) {
  const unique = [...new Set(domains)];
  let i = 0;
  async function worker() {
    while (i < unique.length) {
      const d = unique[i++];
      await resolveGateway(d);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, unique.length) }, worker));
}

function inferMsTenant(bounceText = '') {
  const m = bounceText.match(/\b([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\b/i);
  return m ? m[1] : null;
}

module.exports = { resolveGateway, prewarm, inferMsTenant };