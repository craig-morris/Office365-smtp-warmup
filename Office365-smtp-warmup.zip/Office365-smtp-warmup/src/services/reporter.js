const fs = require('fs');
const path = require('path');
const { createObjectCsvWriter } = require('csv-writer');
const store = require('./store');
const { inferMsTenant } = require('./deliverability');
const { buildSegments } = require('./segments');

const OUT = path.join(__dirname, '..', '..', 'reports');
const stamp = () => new Date().toISOString().replace(/[:.]/g, '-');

function summarise(rows) {
  const g = {};
  for (const r of rows) {
    const k = r.smtpLabel ? `${r.gateway} · ${r.smtpLabel}` : r.gateway || 'Unknown';
    g[k] ||= { total: 0, delivered: 0, failed: 0, replies: 0 };
    g[k].total++;
    if (r.status === 'delivered') g[k].delivered++;
    if (r.status === 'failed') g[k].failed++;
    if (r.replyType) g[k].replies++;
  }
  return g;
}

function summariseDomains(rows) {
  const d = {};
  for (const r of rows) {
    const k = r.to.split('@')[1] || '';
    d[k] ||= { total: 0, delivered: 0, failed: 0, gateway: r.gateway, mx: r.mx };
    d[k].total++;
    if (r.status === 'delivered') d[k].delivered++;
    if (r.status === 'failed') d[k].failed++;
  }
  return d;
}

async function writeReports(campaignId, extras = {}) {
  fs.mkdirSync(OUT, { recursive: true });
  const state = store.load();
  const sends = state.sends.filter(s => !campaignId || s.campaignId === campaignId);
  const replies = state.replies.filter(r => !campaignId || r.campaignId === campaignId);
  const unsubs = (state.unsubscribes || []).filter(u => !campaignId || u.campaignId === campaignId);
  const replyByMsg = new Map(replies.map(r => [r.matchedMessageId, r]));
  const unsubSet = new Set(unsubs.map(u => u.email));

  const rows = sends.map(s => {
    const rep = replyByMsg.get(s.messageId);
    const tenantId = rep?.type === 'bounce' ? inferMsTenant(rep.text) : null;
    return {
      to: s.to,
      gateway: s.gateway || '',
      mx: s.mx || '',
      smtpHost: s.smtpHost || '',
      smtpLabel: s.smtpLabel || '',
      method: s.method || '',
      status: s.status || '',
      response: (s.response || '').replace(/\s+/g, ' ').slice(0, 200),
      messageId: s.messageId,
      sentAt: s.sentAt,
      replyType: rep?.type || '',
      tenantId: tenantId || '',
      unsubscribed: unsubSet.has(s.to) ? 'yes' : '',
    };
  });

  const tag = campaignId ? campaignId.slice(0, 8) : 'all';
  const ts = stamp();
  const csvPath  = path.join(OUT, `warmup-${tag}-${ts}.csv`);
  const htmlPath = path.join(OUT, `warmup-${tag}-${ts}.html`);

  const csv = createObjectCsvWriter({
    path: csvPath,
    header: [
      { id: 'to', title: 'Recipient' },
      { id: 'gateway', title: 'Gateway' },
      { id: 'mx', title: 'MX' },
      { id: 'smtpHost', title: 'SMTP Host' },
      { id: 'smtpLabel', title: 'SMTP Label' },
      { id: 'method', title: 'Delivery Method' },
      { id: 'status', title: 'Status' },
      { id: 'response', title: 'SMTP Response' },
      { id: 'messageId', title: 'Message-ID' },
      { id: 'sentAt', title: 'Sent At' },
      { id: 'replyType', title: 'Reply Type' },
      { id: 'tenantId', title: 'Microsoft Tenant ID' },
      { id: 'unsubscribed', title: 'Unsubscribed' },
    ],
  });
  await csv.writeRecords(rows);

  const byGateway = summarise(rows);
  const byDomain = summariseDomains(rows);

  // Segment CSVs (deliverable / failed / unsubscribed / master + global)
  const segments = buildSegments(campaignId);

  const html = renderHtml({
    rows, byGateway, byDomain, campaignId,
    replyCount: replies.length,
    unsubCount: unsubs.length,
    segments,
    poolSnapshot: extras.smtp || [],
  });
  fs.writeFileSync(htmlPath, html);

  return {
    csvPath, htmlPath,
    summary: byGateway, domains: byDomain, segments,
    totals: {
      sends: rows.length,
      delivered: rows.filter(r => r.status === 'delivered').length,
      failed: rows.filter(r => r.status === 'failed').length,
      replies: replies.length,
      unsubscribed: unsubs.length,
    },
  };
}

function pct(n, d) { return d ? ((n / d) * 100).toFixed(1) + '%' : '—'; }
function klass(p) { const v = parseFloat(p); return isNaN(v) ? '' : v >= 80 ? 'ok' : v >= 50 ? 'warn' : 'bad'; }

function renderHtml({ rows, byGateway, byDomain, campaignId, replyCount, unsubCount, segments, poolSnapshot }) {
  const relSeg = segments ? Object.fromEntries(
    Object.entries(segments).filter(([, v]) => typeof v === 'string')
      .map(([k, v]) => [k, path.relative(OUT, v).replace(/\\/g, '/')]),
  ) : {};

  return `<!doctype html>
<html><head><meta charset="utf-8"><title>SMTP Warmup Report</title>
<style>
 body{font-family:'Segoe UI',Arial,sans-serif;background:#faf9f8;color:#201f1e;margin:0;padding:32px}
 h1{font-size:22px;margin:0 0 4px} h2{font-size:16px;margin:28px 0 8px}
 .meta{color:#605e5c;font-size:13px;margin-bottom:8px}
 table{border-collapse:collapse;width:100%;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.06);border-radius:6px;overflow:hidden;margin-bottom:24px}
 th,td{padding:8px 12px;font-size:13px;text-align:left;border-bottom:1px solid #edebe9}
 th{background:#f3f2f1;font-weight:600;position:sticky;top:0}
 .ok{color:#107c10;font-weight:600} .bad{color:#a4262c;font-weight:600} .warn{color:#8a6100;font-weight:600}
 .pill{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;background:#f3f2f1;color:#323130}
 .grid{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:16px 0 24px}
 .card{background:#fff;padding:14px 16px;border-radius:6px;box-shadow:0 1px 2px rgba(0,0,0,.06)}
 .card .n{font-size:22px;font-weight:600} .card .l{font-size:11px;color:#605e5c;text-transform:uppercase;letter-spacing:.05em}
 a{color:#0078d4}
 code{background:#f3f2f1;padding:2px 6px;border-radius:3px;font-size:12px}
</style></head><body>

<h1>SMTP Warmup Report</h1>
<div class="meta">Campaign <code>${campaignId || 'all'}</code> · Generated ${new Date().toISOString()}</div>

<div class="grid">
  <div class="card"><div class="n">${rows.length}</div><div class="l">Sends</div></div>
  <div class="card"><div class="n ok">${rows.filter(r => r.status === 'delivered').length}</div><div class="l">Delivered</div></div>
  <div class="card"><div class="n bad">${rows.filter(r => r.status === 'failed').length}</div><div class="l">Failed</div></div>
  <div class="card"><div class="n">${replyCount}</div><div class="l">Replies / Bounces</div></div>
  <div class="card"><div class="n warn">${unsubCount}</div><div class="l">Unsubscribed</div></div>
</div>

${poolSnapshot.length ? `
<h2>SMTP Pool Performance</h2>
<table><thead><tr><th>Label</th><th>Host</th><th>Sent</th><th>Failed</th><th>Avg Latency</th><th>State</th></tr></thead><tbody>
${poolSnapshot.map(p => `<tr>
  <td><b>${p.label}</b></td><td>${p.host}</td>
  <td class="ok">${p.sent}</td><td class="bad">${p.failed}</td>
  <td>${p.avgMs} ms</td>
  <td>${p.cooling ? '<span class="warn">cooling</span>' : '<span class="ok">healthy</span>'}</td>
</tr>`).join('')}
</tbody></table>` : ''}

<h2>Gateway Deliverability</h2>
<table><thead><tr><th>Gateway · SMTP</th><th>Total</th><th>Delivered</th><th>Failed</th><th>Replies</th><th>Deliverable</th></tr></thead><tbody>
${Object.entries(byGateway).map(([g, s]) => {
  const p = pct(s.delivered, s.total);
  return `<tr><td>${g}</td><td>${s.total}</td><td class="ok">${s.delivered}</td>
  <td class="bad">${s.failed}</td><td>${s.replies}</td><td class="${klass(p)}">${p}</td></tr>`;
}).join('') || '<tr><td colspan="6">No data</td></tr>'}
</tbody></table>

<h2>Domain / MX Breakdown</h2>
<table><thead><tr><th>Domain</th><th>Gateway</th><th>MX</th><th>Total</th><th>Delivered</th><th>Failed</th><th>Deliverable</th></tr></thead><tbody>
${Object.entries(byDomain).map(([d, s]) => {
  const p = pct(s.delivered, s.total);
  return `<tr><td>${d}</td><td>${s.gateway || ''}</td><td>${s.mx || ''}</td>
  <td>${s.total}</td><td class="ok">${s.delivered}</td><td class="bad">${s.failed}</td>
  <td class="${klass(p)}">${p}</td></tr>`;
}).join('') || '<tr><td colspan="7">No data</td></tr>'}
</tbody></table>

${segments ? `
<h2>Segment Exports</h2>
<table><thead><tr><th>Segment</th><th>Count</th><th>File</th></tr></thead><tbody>
  <tr><td>Deliverable</td><td class="ok">${segments.counts.deliverable}</td><td><a href="${relSeg.deliverable}">${path.basename(segments.deliverable)}</a></td></tr>
  <tr><td>Failed</td><td class="bad">${segments.counts.failed}</td><td><a href="${relSeg.failed}">${path.basename(segments.failed)}</a></td></tr>
  <tr><td>Unsubscribed</td><td class="warn">${segments.counts.unsubscribed}</td><td><a href="${relSeg.unsubscribed}">${path.basename(segments.unsubscribed)}</a></td></tr>
  <tr><td>Master (with metadata)</td><td>${segments.counts.recipients}</td><td><a href="${relSeg.master}">${path.basename(segments.master)}</a></td></tr>
</tbody></table>
<p class="meta">Also maintained globally in <code>reports/segments/_global/</code> — use <code>send-eligible.csv</code> as your canonical clean list.</p>
` : ''}

<h2>Per-Recipient Detail</h2>
<table><thead><tr>
 <th>Recipient</th><th>Gateway</th><th>SMTP</th><th>Status</th>
 <th>Reply</th><th>Unsub</th><th>Tenant</th><th>Sent At</th>
</tr></thead><tbody>
${rows.map(r => `<tr>
 <td>${r.to}</td><td>${r.gateway}</td><td>${r.smtpLabel || r.smtpHost}</td>
 <td class="${r.status === 'delivered' ? 'ok' : 'bad'}">${r.status}</td>
 <td>${r.replyType ? `<span class="pill">${r.replyType}</span>` : '—'}</td>
 <td>${r.unsubscribed ? '<span class="warn">yes</span>' : '—'}</td>
 <td>${r.tenantId || '—'}</td>
 <td>${r.sentAt}</td>
</tr>`).join('') || '<tr><td colspan="8">No sends</td></tr>'}
</tbody></table>

</body></html>`;
}

module.exports = { writeReports };