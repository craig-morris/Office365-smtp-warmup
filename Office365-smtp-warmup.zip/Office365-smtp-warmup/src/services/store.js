const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const FILE = path.join(DATA_DIR, 'state.json');

const EMPTY = { campaigns: {}, sends: [], replies: [], unsubscribes: [] };

function ensure() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify(EMPTY, null, 2));
}

function load() {
  ensure();
  try {
    const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    return { ...structuredClone(EMPTY), ...raw };
  } catch { return structuredClone(EMPTY); }
}

function save(state) { ensure(); fs.writeFileSync(FILE, JSON.stringify(state, null, 2)); }

function addCampaign(c)  { const s = load(); s.campaigns[c.id] = c; save(s); }
function recordSend(row) { const s = load(); s.sends.push(row); save(s); }
function recordReply(row){ const s = load(); s.replies.push(row); save(s); }

function recordUnsubscribe({ email, campaignId, source = 'link' }) {
  const s = load();
  if (!s.unsubscribes.some(u => u.email === email && u.campaignId === campaignId)) {
    s.unsubscribes.push({
      email, campaignId: campaignId || null,
      source, at: new Date().toISOString(),
    });
    save(s);
    return true;
  }
  return false;
}

function isUnsubscribed(email) {
  const s = load();
  return s.unsubscribes.some(u => u.email === email);
}

function getKnownMessageIds() {
  return new Set(load().sends.map(r => r.messageId).filter(Boolean));
}

module.exports = {
  load, save, addCampaign, recordSend, recordReply,
  recordUnsubscribe, isUnsubscribed, getKnownMessageIds,
};