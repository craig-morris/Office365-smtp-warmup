const fs = require('fs');
const path = require('path');
const store = require('./store');

const SEG_ROOT = path.join(__dirname, '..', '..', 'reports', 'segments');
const GLOBAL_DIR = path.join(SEG_ROOT, '_global');

function ensure(dir) { fs.mkdirSync(dir, { recursive: true }); }

function writeList(filePath, emails) {
  ensure(path.dirname(filePath));
  const unique = [...new Set(emails)];
  fs.writeFileSync(filePath, unique.join('\n') + (unique.length ? '\n' : ''));
  return filePath;
}

function writeMaster(filePath, rows) {
  ensure(path.dirname(filePath));
  const header = ['email', 'name', 'company', 'gateway', 'mx', 'smtpHost', 'method', 'status', 'replyType', 'sentAt', 'campaignId'];
  const lines = [header.join(',')];
  for (const r of rows) {
    lines.push(header.map(k => csvCell(r[k])).join(','));
  }
  fs.writeFileSync(filePath, lines.join('\n'));
  return filePath;
}

function csvCell(v) {
  if (v == null) return '';
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function buildSegments(campaignId) {
  const state = store.load();
  const sends = state.sends.filter(s => !campaignId || s.campaignId === campaignId);
  const replies = state.replies.filter(r => !campaignId || r.campaignId === campaignId);
  const unsubs = (state.unsubscribes || []).filter(u => !campaignId || u.campaignId === campaignId);

  const replyByMsgId = new Map(replies.map(r => [r.matchedMessageId, r]));

  const byEmail = new Map();
  for (const s of sends) {
    const e = s.to;
    if (!byEmail.has(e)) byEmail.set(e, { email: e, rows: [], replies: [] });
    byEmail.get(e).rows.push(s);
    const rep = replyByMsgId.get(s.messageId);
    if (rep) byEmail.get(e).replies.push(rep);
  }

  const deliverable = [];
  const failed = [];
  const unsubSet = new Set(unsubs.map(u => u.email));
  const masterRows = [];

  for (const [email, info] of byEmail) {
    const delivered = info.rows.some(r => r.status === 'delivered');
    const failedAny = info.rows.some(r => r.status === 'failed');
    const replyType = info.replies[0]?.type || '';
    const row = info.rows[0];

    if (delivered) deliverable.push(email);
    if (failedAny) failed.push(email);

    masterRows.push({
      email,
      name: row.name || '',
      company: row.company || '',
      gateway: row.gateway || '',
      mx: row.mx || '',
      smtpHost: row.smtpHost || '',
      method: row.method || '',
      status: delivered ? 'delivered' : failedAny ? 'failed' : 'unknown',
      replyType,
      sentAt: row.sentAt || '',
      campaignId: row.campaignId || '',
    });
  }

  const dir = campaignId ? path.join(SEG_ROOT, campaignId) : GLOBAL_DIR;
  ensure(dir);

  const out = {
    dir,
    deliverable: writeList(path.join(dir, 'deliverable.csv'), deliverable),
    failed: writeList(path.join(dir, 'failed.csv'), failed),
    unsubscribed: writeList(path.join(dir, 'unsubscribed.csv'), [...unsubSet]),
    master: writeMaster(path.join(dir, 'master.csv'), masterRows),
    counts: {
      recipients: byEmail.size,
      deliverable: deliverable.length,
      failed: failed.length,
      unsubscribed: unsubSet.size,
    },
  };

  // Global aggregates
  ensure(GLOBAL_DIR);
  const globalDeliverable = new Set();
  const globalFailed = new Set();
  const globalUnsub = new Set();
  for (const s of state.sends) if (s.status === 'delivered') globalDeliverable.add(s.to);
  for (const s of state.sends) if (s.status === 'failed') globalFailed.add(s.to);
  for (const u of (state.unsubscribes || [])) globalUnsub.add(u.email);

  writeList(path.join(GLOBAL_DIR, 'deliverable.csv'), [...globalDeliverable]);
  writeList(path.join(GLOBAL_DIR, 'failed.csv'), [...globalFailed]);
  writeList(path.join(GLOBAL_DIR, 'unsubscribed.csv'), [...globalUnsub]);
  writeList(
    path.join(GLOBAL_DIR, 'send-eligible.csv'),
    [...globalDeliverable].filter(e => !globalUnsub.has(e)),
  );

  return out;
}

module.exports = { buildSegments };