const { buildTransport } = require('../mail/smtp');

class SmtpPool {
  constructor(configs) {
    this.servers = configs.map((c, i) => {
      // Envelope + From must be the authenticated mailbox for M365 SMTP AUTH.
      // Derive from `user` when it looks like an email; allow explicit override.
      const derived = /@/.test(c.user || '') ? c.user : null;
      return {
        ...c,
        label: c.label || `smtp-${i + 1}`,
        weight: Math.max(1, Number(c.weight || 1)),
        fromEmail: c.fromEmail || derived,      // used as From + envelope sender
        transport: buildTransport(c),
        stats: { sent: 0, failed: 0, totalMs: 0 },
        cooldownUntil: 0,
      };
    });
  }

  acquire() {
    const now = Date.now();
    const healthy = this.servers.filter(s => s.cooldownUntil < now);
    const pool = healthy.length ? healthy : this.servers;
    const total = pool.reduce((a, s) => a + s.weight, 0);
    let r = Math.random() * total;
    for (const s of pool) {
      r -= s.weight;
      if (r <= 0) return s;
    }
    return pool[0];
  }

  recordSuccess(server, ms) {
    server.stats.sent++;
    server.stats.totalMs += ms;
    server.cooldownUntil = 0;
  }

  recordFailure(server) {
    server.stats.failed++;
    const total = server.stats.sent + server.stats.failed;
    if (total >= 5 && server.stats.failed / total > 0.5) {
      server.cooldownUntil = Date.now() + 60_000;
    }
  }

  async verifyAll() {
    const results = await Promise.allSettled(
      this.servers.map(s => s.transport.verify()),
    );
    return this.servers.map((s, i) => ({
      label: s.label,
      host: s.host,
      fromEmail: s.fromEmail,
      ok: results[i].status === 'fulfilled',
      error: results[i].status === 'rejected' ? results[i].reason?.message : null,
    }));
  }

  snapshot() {
    return this.servers.map(s => ({
      label: s.label,
      host: s.host,
      fromEmail: s.fromEmail,
      sent: s.stats.sent,
      failed: s.stats.failed,
      avgMs: s.stats.sent ? Math.round(s.stats.totalMs / s.stats.sent) : 0,
      cooling: s.cooldownUntil > Date.now(),
    }));
  }

  closeAll() { this.servers.forEach(s => { try { s.transport.close(); } catch {} }); }
}

module.exports = { SmtpPool };