const fs = require('fs');
const path = require('path');
const config = require('../config');
const log = require('../utils/logger');

const { botToken, chatId } = config.telegram;
const enabled = Boolean(botToken && chatId);

async function post(method, body) {
  if (!enabled) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${botToken}/${method}`, {
      method: 'POST',
      body,
    });
    if (!res.ok) log.warn(`Telegram ${method} ${res.status}: ${await res.text()}`);
    return res.json();
  } catch (e) {
    log.warn(`Telegram ${method} failed: ${e.message}`);
    return null;
  }
}

async function sendMessage(text, { parseMode = 'HTML' } = {}) {
  if (!enabled) return null;
  const fd = new FormData();
  fd.append('chat_id', chatId);
  fd.append('text', text);
  fd.append('parse_mode', parseMode);
  fd.append('disable_web_page_preview', 'true');
  return post('sendMessage', fd);
}

async function sendDocument(filePath, caption = '') {
  if (!enabled) return null;
  if (!fs.existsSync(filePath)) return null;
  const buf = fs.readFileSync(filePath);
  const fd = new FormData();
  fd.append('chat_id', chatId);
  fd.append('caption', caption);
  fd.append('document', new Blob([buf]), path.basename(filePath));
  return post('sendDocument', fd);
}

const notify = {
  campaignStart: (id, total, industry, poolLabels) => sendMessage(
    `🚀 <b>Campaign started</b>\n` +
    `<code>${id}</code>\n` +
    `Recipients: <b>${total}</b>\n` +
    `Industry: <b>${industry}</b>\n` +
    `SMTP pool: ${poolLabels.join(', ')}`,
  ),
  campaignDone: (id, totals, report) => sendMessage(
    `✅ <b>Campaign complete</b>\n` +
    `<code>${id}</code>\n` +
    `Delivered: <b>${totals.delivered}</b> / ${totals.sends}\n` +
    `Failed: <b>${totals.failed}</b>\n` +
    `Replies: <b>${totals.replies}</b>\n` +
    `Report: <code>${report?.htmlPath ? path.basename(report.htmlPath) : 'n/a'}</code>`,
  ),
  unsubscribe: (email, campaignId) => sendMessage(
    `🚫 <b>Unsubscribe</b>\n` +
    `<code>${email}</code>\n` +
    `Campaign: <code>${campaignId || 'global'}</code>`,
  ),
  failure: (email, smtpLabel, error) => sendMessage(
    `⚠️ <b>Send failed</b>\n` +
    `To: <code>${email}</code>\n` +
    `SMTP: <b>${smtpLabel}</b>\n` +
    `Error: <code>${String(error).slice(0, 200)}</code>`,
  ),
  custom: sendMessage,
  document: sendDocument,
  enabled,
};

module.exports = notify;