const { EventEmitter } = require('events');
const emitter = new EventEmitter();
emitter.setMaxListeners(100);

const history = new Map(); // campaignId -> array of events (for late subscribers)

function emit(campaignId, payload) {
  const evt = { ts: Date.now(), ...payload };
  if (!history.has(campaignId)) history.set(campaignId, []);
  history.get(campaignId).push(evt);
  emitter.emit(campaignId, evt);
}

function subscribe(campaignId, fn) {
  // Replay history so a page refresh doesn't miss progress.
  (history.get(campaignId) || []).forEach(fn);
  emitter.on(campaignId, fn);
  return () => emitter.off(campaignId, fn);
}

module.exports = { emit, subscribe };