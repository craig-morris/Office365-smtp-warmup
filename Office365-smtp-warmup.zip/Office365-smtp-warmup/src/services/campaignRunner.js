const crypto = require('crypto');
const path = require('path');
const { generate } = require('../content/generator');
const { sendOne } = require('../mail/smtp');
const { pollInbox } = require('../mail/imap');
const { SmtpPool } = require('./smtpPool');
const { resolveGateway, prewarm } = require('./deliverability');
const { buildFooter } = require('../content/footer');
const { buildUrl: buildUnsubUrl } = require('./unsubscribe');
const notify = require('./telegram');
const store = require('./store');
const bus = require('./eventBus');
const log = require('../utils/logger');
const { writeReports } = require('./reporter');
const config = require('../config');

async function runWithPool(items, concurrency, worker) {
  const out = new Array(items.length);
  let i = 0;
  async function next() {
    while (true) {
      const idx = i++;
      if (idx >= items.length) return;
      try { out[idx] = await worker(items[idx], idx); }
      catch (e) { out[idx] = { error: e.message }; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length || 1) }, next));
  return out;
}

const jitter = (ms) => new Promise(r => setTimeout(r, Math.random() * ms));

async function runCampaign(cfg) {
  const campaignId = cfg.campaignId || crypto.randomUUID();
  const {
    sender, recipients = [], industry = 'saas',
    replyTo, listUnsubMail, listUnsubUrl,
    imap, useHtml = true,
    concurrency = 12,
    jitterMs = 150,
  } = cfg;

  const smtpList = Array.isArray(cfg.smtp) ? cfg.smtp : [cfg.smtp].filter(Boolean);
  if (!smtpList.length || !smtpList[0]?.host) throw new Error('at least one smtp.host is required');
  if (!sender?.email) throw new Error('sender.email is required');
  if (!recipients.length) throw new Error('recipients[] is required');

  const eligible = recipients.filter(r => !store.isUnsubscribed(r.email));
  const skipped = recipients.length - eligible.length;
  if (skipped) log.info(`Skipped ${skipped} unsubscribed recipient(s)`);

  store.addCampaign({
    id: campaignId,
    createdAt: new Date().toISOString(),
    industry, sender,
    smtpHosts: smtpList.map(s => s.host),
    recipientCount: eligible.length,
    skippedUnsubscribed: skipped,
    concurrency,
  });

  const pool = new SmtpPool(smtpList);
  const poolHealth = await pool.verifyAll();
  const healthy = poolHealth.filter(h => h.ok);
  if (!healthy.length) {
    pool.closeAll();
    const msg = 'No SMTP server passed verification';
    bus.emit(campaignId, { type: 'error', message: msg });
    throw new Error(msg);
  }

  bus.emit(campaignId, { type: 'start', total: eligible.length, pool: poolHealth });
  await notify.campaignStart(campaignId, eligible.length, industry, healthy.map(h => h.label));

  const domains = eligible.map(r => r.email.split('@')[1]).filter(Boolean);
  await prewarm(domains);
  bus.emit(campaignId, { type: 'resolved', domains: [...new Set(domains)].length });

  let done = 0;
  const sent = await runWithPool(eligible, concurrency, async (r) => {
    const server = pool.acquire();
    const { gateway, mx } = await resolveGateway(r.email.split('@')[1]);

    // Per-server From. If none derivable and no override, this is a config error.
    const fromEmail = server.fromEmail;
    if (!fromEmail) {
      const msg = `SMTP ${server.label} has no fromEmail (set user to an email or provide fromEmail)`;
      log.warn(msg);
      bus.emit(campaignId, { type: 'error', message: msg });
      return { error: msg };
    }

    const from = { name: sender.name || 'Team', email: fromEmail };
    const content = generate({ industry, recipient: r, sender: from, htmlMode: useHtml });

    const unsubUrl = buildUnsubUrl(r.email, campaignId);
    const footer = buildFooter({
      sender: from, unsubUrl,
      reference: content.messageId.replace(/[<>]/g, '').slice(0, 18),
    });
    const finalText = `${content.text}\n${footer.text}`;
    const finalHtml = content.html ? `${content.html}\n${footer.html}` : undefined;

    let status = 'failed', response = '', t0 = Date.now();
    try {
      const info = await sendOne(server.transport, {
        from, to: r,
        subject: content.subject,
        text: finalText, html: finalHtml,
        messageId: content.messageId,
        listUnsubMail: listUnsubMail || undefined,
        listUnsubUrl: unsubUrl,
        replyTo,
      });
      status = 'delivered';
      response = info.response || 'accepted';
      pool.recordSuccess(server, Date.now() - t0);
    } catch (e) {
      response = e.message;
      pool.recordFailure(server);
      log.warn(`Send failed for ${r.email} via ${server.label}: ${e.message}`);
      notify.failure(r.email, server.label, e.message).catch(() => {});
    }

    const row = {
      campaignId,
      to: r.email, name: r.name, company: r.company,
      fromEmail,                 // NEW: which mailbox sent this
      gateway, mx,
      smtpHost: server.host, smtpLabel: server.label,
      method: `SMTP ${server.host}:${server.port}`,
      status, response,
      messageId: content.messageId,
      subject: content.subject,
      sentAt: new Date().toISOString(),
      industry,
    };
    store.recordSend(row);

    done++;
    bus.emit(campaignId, {
      type: 'progress', done, total: eligible.length,
      to: r.email, status, smtp: server.label, from: fromEmail,
    });
    if (jitterMs) await jitter(jitterMs);
    return row;
  });

  pool.closeAll();
  bus.emit(campaignId, { type: 'sent', count: sent.length, pool: pool.snapshot() });

  if (imap?.host) {
    try {
      bus.emit(campaignId, { type: 'imap', state: 'polling' });
      await pollInbox(imap, {
        knownMessageIds: store.getKnownMessageIds(),
        onReply: (rec) => {
          store.recordReply({ ...rec, campaignId });
          if (rec.type === 'reply' && /\bunsubscribe\b/i.test(rec.text || '')) {
            store.recordUnsubscribe({ email: rec.from, campaignId, source: 'reply' });
            notify.unsubscribe(rec.from, campaignId).catch(() => {});
          }
        },
      });
      bus.emit(campaignId, { type: 'imap', state: 'done' });
    } catch (e) {
      log.warn(`Inbound poll failed: ${e.message}`);
      bus.emit(campaignId, { type: 'imap', state: 'error', message: e.message });
    }
  }

  const report = await writeReports(campaignId, { smtp: pool.snapshot(), senderAddress: config.senderAddress });

  if (notify.enabled) {
    notify.campaignDone(campaignId, report.totals, report).catch(() => {});
    for (const f of [report.htmlPath, report.csvPath, report.segments?.deliverable, report.segments?.failed, report.segments?.unsubscribed]) {
      if (f) notify.document(f, path.basename(f)).catch(() => {});
    }
  }

  bus.emit(campaignId, { type: 'done', report });
  return { campaignId, sent, report };
}

module.exports = { runCampaign };