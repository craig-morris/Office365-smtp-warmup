const express = require('express');
const router = express.Router();
const { generate, listIndustries } = require('../content/generator');

router.get('/industries', (_req, res) => res.json(listIndustries()));

router.post('/preview', (req, res) => {
  const { industry = 'saas', recipient = { email: 'test@example.com', name: 'Test User' },
          sender = { email: 'me@example.com', name: 'Me' }, htmlMode = true } = req.body || {};
  res.json(generate({ industry, recipient, sender, htmlMode }));
});

module.exports = router;