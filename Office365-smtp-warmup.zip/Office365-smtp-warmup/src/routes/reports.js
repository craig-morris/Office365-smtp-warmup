const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { writeReports } = require('../services/reporter');

const OUT = path.join(__dirname, '..', '..', 'reports');

// GET /api/reports — list report files
router.get('/', (_req, res) => {
  if (!fs.existsSync(OUT)) return res.json([]);
  const files = fs.readdirSync(OUT)
    .filter(f => f.endsWith('.html') || f.endsWith('.csv'))
    .sort()
    .reverse();
  res.json(files);
});

// GET /api/reports/generate?campaignId=...
router.get('/generate', async (req, res) => {
  const { campaignId } = req.query;
  try {
    const r = await writeReports(campaignId || null);
    res.json(r);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/reports/download/:file
router.get('/download/:file', (req, res) => {
  const file = path.basename(req.params.file); // prevent traversal
  const full = path.join(OUT, file);
  if (!fs.existsSync(full)) return res.status(404).end();
  res.sendFile(full);
});

module.exports = router;