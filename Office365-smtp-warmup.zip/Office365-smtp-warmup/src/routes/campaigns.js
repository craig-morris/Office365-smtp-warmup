const crypto = require('crypto');
const express = require('express');
const router = express.Router();

const { runCampaign } = require('../services/campaignRunner');
const store = require('../services/store');
const bus = require('../services/eventBus');
const env = require('../config');

const pending = new Map(); // campaignId -> cfg

/** Only fall back to env SMTP when the client sent nothing. */
function mergeDefaults(cfg) {
  if (!cfg.smtp || (Array.isArray(cfg.smtp) && !cfg.smtp.length)) {
    cfg.smtp = { ...env.smtp };
  }
  cfg.imap = { ...env.imap, ...(cfg.imap || {}) };
  cfg.listUnsubMail ??= env.listUnsubMail;
  cfg.listUnsubUrl  ??= env.listUnsubUrl;
  cfg.concurrency ??= 12;
  cfg.jitterMs ??= 150;
  return cfg;
}

/**
 * POST /api/campaigns/prepare
 * Stages a config and returns a campaignId the client can subscribe to.
 */
router.post('/prepare', (req, res) => {
  const id = crypto.randomUUID();
  pending.set(id, req.body || {});
  res.json({ campaignId: id });
});

/**
 * POST /api/campaigns/run/:campaignId
 * Runs a prepared campaign, emitting SSE events under that id.
 */
router.post('/run/:campaignId', async (req, res) => {
  const { campaignId } = req.params;
  const cfg = pending.get(campaignId);
  if (!cfg) return res.status(404).json({ error: 'unknown campaign id' });

  mergeDefaults(cfg);
  cfg.campaignId = campaignId;

  try {
    const result = await runCampaign(cfg);
    res.json(result);
  } catch (e) {
    bus.emit(campaignId, { type: 'error', message: e.message });
    res.status(400).json({ error: e.message });
  } finally {
    pending.delete(campaignId);
  }
});

/**
 * POST /api/campaigns/run
 * One-shot: runs immediately, no SSE. For curl / testing.
 */
router.post('/run', async (req, res) => {
  try {
    const cfg = mergeDefaults(req.body || {});
    const result = await runCampaign(cfg);
    res.json(result);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.get('/', (_req, res) => {
  const state = store.load();
  res.json(Object.values(state.campaigns));
});

/** SSE stream of live campaign progress. */
router.get('/stream/:campaignId', (req, res) => {
  const { campaignId } = req.params;

  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.flushHeaders?.();

  const send = (evt) => res.write(`data: ${JSON.stringify(evt)}\n\n`);
  const unsub = bus.subscribe(campaignId, send);
  const ping = setInterval(() => res.write(': ping\n\n'), 15000);

  req.on('close', () => {
    unsub();
    clearInterval(ping);
    try { res.end(); } catch {}
  });
});

module.exports = router;