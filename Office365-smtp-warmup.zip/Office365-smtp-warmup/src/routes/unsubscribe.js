const express = require('express');
const router = express.Router();
const { verifyToken } = require('../services/unsubscribe');
const store = require('../services/store');
const notify = require('../services/telegram');

router.get('/:token', async (req, res) => {
  const info = verifyToken(req.params.token);
  if (!info) return res.status(400).send(page('Invalid link', 'This unsubscribe link is not valid.'));

  const added = store.recordUnsubscribe({
    email: info.email, campaignId: info.campaignId, source: 'link',
  });
  if (added) notify.unsubscribe(info.email, info.campaignId).catch(() => {});

  res.send(page('Unsubscribed', `<b>${info.email}</b> has been removed from future sends.`));
});

// RFC 8058 one-click
router.post('/:token', (req, res) => {
  const info = verifyToken(req.params.token);
  if (!info) return res.status(400).end();
  const added = store.recordUnsubscribe({
    email: info.email, campaignId: info.campaignId, source: 'one-click',
  });
  if (added) notify.unsubscribe(info.email, info.campaignId).catch(() => {});
  res.status(200).end();
});

function page(title, body) {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
<style>body{font-family:'Segoe UI',Arial,sans-serif;background:#faf9f8;color:#201f1e;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.box{background:#fff;padding:32px 40px;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,.08);text-align:center}
h1{font-size:20px;margin:0 0 8px}p{color:#605e5c;margin:0}</style></head>
<body><div class="box"><h1>${title}</h1><p>${body}</p></div></body></html>`;
}

module.exports = router;