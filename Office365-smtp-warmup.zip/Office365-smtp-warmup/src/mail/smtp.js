const nodemailer = require('nodemailer');
const { buildHeaders } = require('./headers');

function buildTransport(smtp) {
  return nodemailer.createTransport({
    host: smtp.host,
    port: Number(smtp.port),
    secure: Boolean(smtp.secure ?? Number(smtp.port) === 465),
    auth: smtp.user ? { user: smtp.user, pass: smtp.pass } : undefined,
    pool: true,
    maxConnections: smtp.maxConnections ?? 3,
    maxMessages: smtp.maxMessages ?? 100,
    tls: { minVersion: 'TLSv1.2', servername: smtp.host },
    connectionTimeout: 20_000,
    greetingTimeout: 15_000,
    socketTimeout: 30_000,
  });
}

async function verifyTransport(t) { return t.verify(); }

async function sendOne(transport, opts) {
  const {
    from, to, subject, text, html, messageId,
    listUnsubMail, listUnsubUrl, replyTo, transactional = true,
  } = opts;

  const fromDomain = from.email.split('@')[1];
  const headers = buildHeaders({ messageId, fromDomain, listUnsubMail, listUnsubUrl, transactional });

  return transport.sendMail({
    from: `"${from.name}" <${from.email}>`,
    to: to.email,
    replyTo: replyTo || from.email,
    subject, text, html: html || undefined, headers,
  });
}

module.exports = { buildTransport, verifyTransport, sendOne };