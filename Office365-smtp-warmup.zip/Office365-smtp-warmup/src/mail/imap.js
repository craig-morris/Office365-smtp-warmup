const { ImapFlow } = require('imapflow');
const { simpleParser } = require('mailparser');

/**
 * Poll INBOX for new messages, classify them, and hand to onReply.
 * knownMessageIds: Set of Message-IDs we sent, so we can match replies.
 */
async function pollInbox(imapCfg, { knownMessageIds = new Set(), onReply, markSeen = true }) {
  const client = new ImapFlow({
    host: imapCfg.host,
    port: Number(imapCfg.port || 993),
    secure: true,
    auth: { user: imapCfg.user, pass: imapCfg.pass },
    logger: false,
  });

  const results = [];
  await client.connect();
  const lock = await client.getMailboxLock('INBOX');
  try {
    for await (const msg of client.fetch({ seen: false }, { envelope: true, source: true, uid: true })) {
      const parsed = await simpleParser(msg.source);
      const inReplyTo = parsed.inReplyTo || '';
      const refs = (parsed.references || []).join(' ');
      const matched = [...knownMessageIds].find(id => inReplyTo.includes(id) || refs.includes(id)) || null;

      const fromText = parsed.from?.text || '';
      const subject = parsed.subject || '';
      const autoHeader = parsed.headers.get('auto-submitted') || '';

      const isBounce = /mailer-daemon|postmaster/i.test(fromText) ||
                       /delivery (has failed|status notification)|undeliverable/i.test(subject);
      const isAuto = String(autoHeader).toLowerCase() === 'auto-replied' ||
                     /out of office|auto[- ]?reply|automatic reply/i.test(subject);

      const record = {
        from: parsed.from?.value?.[0]?.address || '',
        to: parsed.to?.value?.[0]?.address || '',
        subject,
        receivedAt: (parsed.date || new Date()).toISOString(),
        inReplyTo,
        matchedMessageId: matched,
        type: isBounce ? 'bounce' : isAuto ? 'autoreply' : 'reply',
        text: (parsed.text || '').slice(0, 4000),
      };

      results.push(record);
      if (onReply) await onReply(record);

      if (markSeen) {
        try { await client.messageFlagsAdd(msg.uid, ['\\Seen'], { uid: true }); } catch {}
      }
    }
  } finally {
    lock.release();
    await client.logout();
  }
  return results;
}

module.exports = { pollInbox };