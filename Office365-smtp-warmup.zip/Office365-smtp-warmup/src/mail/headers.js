const crypto = require('crypto');

/**
 * Transactional-styled header set:
 *  - Microsoft-Outlook rendering hints
 *  - Suppress auto-reply loops on our own sends
 *  - Feedback-ID for ESP-level reputation signalling
 *  - List-Unsubscribe for compliance (mailto + URL, one-click)
 * Deliberately omits bulk markers like Precedence: bulk, X-Campaign-ID, List-ID.
 */
function buildHeaders({ messageId, fromDomain, listUnsubMail, listUnsubUrl, transactional = true }) {
  const unsub = [];
  if (listUnsubMail) unsub.push(`<mailto:${listUnsubMail}?subject=unsubscribe>`);
  if (listUnsubUrl)  unsub.push(`<${listUnsubUrl}>`);

  const headers = {
    'Message-ID': messageId,
    'MIME-Version': '1.0',
    'X-Mailer': 'Microsoft Outlook 16.0',
    'X-MimeOLE': 'Produced By Microsoft MimeOLE V16.0.14334.20000',
    'X-MSMail-Priority': 'Normal',
    'Importance': 'Normal',
    'Priority': '3',
    'Auto-Submitted': 'no',
    'X-Auto-Response-Suppress': 'OOF, AutoReply',
    'Feedback-ID': `${crypto.randomUUID()}:${fromDomain}:txn`,
  };

  if (transactional) {
    // Small hint that this is a one-to-one style message (many filters look at this)
    headers['X-Entity-Ref-ID'] = crypto.randomUUID();
  }

  if (unsub.length) {
    headers['List-Unsubscribe'] = unsub.join(', ');
    headers['List-Unsubscribe-Post'] = 'List-Unsubscribe=One-Click';
  }
  return headers;
}

module.exports = { buildHeaders };