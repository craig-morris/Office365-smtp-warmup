const config = require('../config');

function buildFooter({ sender, unsubUrl, reference }) {
  const addr = config.senderAddress;
  const text = [
    '',
    '—',
    `${sender.name}`,
    addr,
    '',
    `You are receiving this because of an existing relationship with ${sender.name}.`,
    `Unsubscribe: ${unsubUrl}`,
    `Reference: ${reference}`,
  ].join('\n');

  const html = `
<div style="font-family:'Segoe UI',Arial,sans-serif;font-size:12px;color:#6b6b6b;line-height:1.5;margin-top:28px;padding-top:16px;border-top:1px solid #e6e4e2">
  <p style="margin:0 0 6px;color:#3b3a39;font-weight:600">${sender.name}</p>
  <p style="margin:0 0 12px">${addr}</p>
  <p style="margin:0 0 6px">You are receiving this because of an existing relationship with ${sender.name}.</p>
  <p style="margin:0 0 4px"><a href="${unsubUrl}" style="color:#0078d4;text-decoration:none">Unsubscribe</a></p>
  <p style="margin:0;color:#8a8886;font-size:11px">Reference: ${reference}</p>
</div>`.trim();

  return { text, html };
}

module.exports = { buildFooter };