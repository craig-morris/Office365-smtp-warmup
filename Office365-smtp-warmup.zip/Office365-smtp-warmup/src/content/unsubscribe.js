const crypto = require('crypto');
const config = require('../config');

function b64url(s) { return Buffer.from(s).toString('base64url'); }
function sign(payload) {
  return crypto.createHmac('sha256', config.unsubSecret).update(payload).digest('base64url');
}

function makeToken(email, campaignId) {
  const payload = b64url(`${email}|${campaignId}`);
  return `${payload}.${sign(payload)}`;
}

function verifyToken(token) {
  if (!token || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  const expected = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  const [email, campaignId] = Buffer.from(payload, 'base64url').toString().split('|');
  if (!email) return null;
  return { email, campaignId };
}

function buildUrl(email, campaignId) {
  return `${config.publicBaseUrl}/unsubscribe/${makeToken(email, campaignId)}`;
}

module.exports = { makeToken, verifyToken, buildUrl };