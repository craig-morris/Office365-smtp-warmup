// Content banks. Each industry has subjects, openers, bodies, closers,
// and a `tokens` map for {placeholder} substitution (each key → array of values).
module.exports = {
  saas: {
    subjects: [
      "Quick question about {company}'s {pain}",
      "{firstName}, 3 ways {industry} teams cut {metric} this quarter",
      "Re: {pain} at {company}",
      "Idea for {company} — {metric} without a rip-and-replace",
    ],
    openers: ["Hi {firstName},", "Hey {firstName},", "Hello {firstName},"],
    bodies: [
      "Noticed {company} is scaling — most teams at that stage hit {pain} around the same time.",
      "We help {industry} teams reduce {metric} by roughly {number}% without changing their stack.",
      "Curious whether {pain} is on your roadmap this quarter, or if it's parked for now.",
      "If it's useful I can send a short teardown of how two other {industry} teams handled this.",
    ],
    closers: ["— {senderName}", "Best,\n{senderName}", "Thanks,\n{senderName}"],
    tokens: {
      pain:   ["onboarding drag", "seat sprawl", "churn at renewal", "integration debt"],
      metric: ["CAC", "time-to-value", "MTTR", "activation rate"],
    },
  },

  healthcare: {
    subjects: [
      "{firstName}, HIPAA-safe {pain} workflows",
      "Question about {company}'s {metric}",
      "Reducing {pain} without new headcount",
    ],
    openers: ["Hi {firstName},", "Dr. {firstName},", "Hello {firstName},"],
    bodies: [
      "Most clinics around {company}'s size hit {pain} when they scale intake.",
      "We've helped {industry} orgs cut {metric} while staying inside existing compliance boundaries.",
      "Would a 15-minute call next week be useful, or should I just email a one-pager?",
    ],
    closers: ["— {senderName}", "Best regards,\n{senderName}", "Thanks,\n{senderName}"],
    tokens: {
      pain:   ["charting overhead", "no-show rates", "referral leakage"],
      metric: ["staff hours per patient", "denial rate", "time-to-booking"],
    },
  },

  finance: {
    subjects: [
      "{firstName}, tightening {metric} at {company}",
      "Re: {pain} in {industry}",
      "Quick idea for {company}'s reporting cycle",
    ],
    openers: ["Hi {firstName},", "Hello {firstName},"],
    bodies: [
      "Firms like {company} usually feel {pain} most during quarter-end close.",
      "We help {industry} teams reduce {metric} without adding another vendor to the stack.",
      "Worth a short call, or should I send a two-paragraph summary instead?",
    ],
    closers: ["— {senderName}", "Best,\n{senderName}"],
    tokens: {
      pain:   ["reconciliation time", "manual approvals", "audit prep"],
      metric: ["close cycle time", "exception rate", "reconciliation cost"],
    },
  },

  realestate: {
    subjects: ["{firstName}, {pain} at {company}", "Idea for {company}'s pipeline"],
    openers: ["Hi {firstName},", "Hey {firstName},"],
    bodies: [
      "Most brokerages your size fight {pain} once listing volume picks up.",
      "We help {industry} teams improve {metric} without new tooling for agents.",
      "Want me to send the short version, or jump on a call?",
    ],
    closers: ["— {senderName}", "Best,\n{senderName}"],
    tokens: {
      pain:   ["lead follow-up lag", "listing coordination", "agent churn"],
      metric: ["lead-to-tour rate", "days on market", "agent retention"],
    },
  },

  ecommerce: {
    subjects: ["{firstName}, {pain} on {company}'s storefront", "Re: {metric} at {company}"],
    openers: ["Hi {firstName},", "Hey {firstName},"],
    bodies: [
      "Stores at {company}'s volume usually feel {pain} right around peak season.",
      "We help {industry} brands move {metric} without adding another app to Shopify.",
      "Want the teardown or a call?",
    ],
    closers: ["— {senderName}", "Best,\n{senderName}"],
    tokens: {
      pain:   ["cart abandonment", "return rate", "support backlog"],
      metric: ["AOV", "repeat purchase rate", "CAC"],
    },
  },

  education: {
    subjects: ["{firstName}, {pain} at {company}", "Quick question re: {metric}"],
    openers: ["Hi {firstName},", "Hello {firstName},"],
    bodies: [
      "Schools your size tend to feel {pain} most during enrollment windows.",
      "We help {industry} teams improve {metric} without extra admin load.",
      "Open to a short call this week?",
    ],
    closers: ["— {senderName}", "Best,\n{senderName}"],
    tokens: {
      pain:   ["application drop-off", "advisor caseload", "reporting lag"],
      metric: ["yield rate", "advisor:student ratio", "time-to-decision"],
    },
  },

  manufacturing: {
    subjects: ["{firstName}, {pain} on the floor", "Re: {metric} at {company}"],
    openers: ["Hi {firstName},", "Hello {firstName},"],
    bodies: [
      "Plants your size usually feel {pain} once demand picks up.",
      "We help {industry} teams improve {metric} without replacing existing MES.",
      "Want a short walkthrough, or a one-pager?",
    ],
    closers: ["— {senderName}", "Best,\n{senderName}"],
    tokens: {
      pain:   ["downtime events", "changeover time", "QC rework"],
      metric: ["OEE", "scrap rate", "cycle time"],
    },
  },

  legal: {
    subjects: ["{firstName}, {pain} at {company}", "Quick idea re: {metric}"],
    openers: ["Hi {firstName},", "Hello {firstName},"],
    bodies: [
      "Firms like {company} usually hit {pain} during heavy filing periods.",
      "We help {industry} teams reduce {metric} without another system to train on.",
      "Worth a 15-minute call, or should I just send the summary?",
    ],
    closers: ["— {senderName}", "Best,\n{senderName}"],
    tokens: {
      pain:   ["intake delays", "document review backlog", "matter leakage"],
      metric: ["intake-to-engagement time", "billable hours recovered", "review cost"],
    },
  },
};