const crypto = require('crypto');
const industries = require('./industries');

const pick = arr => arr[Math.floor(Math.random() * arr.length)];

function fill(tpl, ctx) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => ctx[k] ?? `{${k}}`);
}

function buildContext(recipient, sender, industryKey) {
  const bank = industries[industryKey] || industries.saas;
  const tokenCtx = {};
  for (const [k, arr] of Object.entries(bank.tokens || {})) tokenCtx[k] = pick(arr);

  const domain = recipient.email.split('@')[1] || 'example.com';
  return {
    firstName: recipient.name?.split(' ')[0] || recipient.email.split('@')[0],
    company: recipient.company || domain.split('.')[0],
    industry: industryKey,
    senderName: sender.name || 'Team',
    number: Math.floor(Math.random() * 40) + 20,
    ...tokenCtx,
  };
}

function toHtml(text) {
  return `<div style="font-family:'Segoe UI',Arial,sans-serif;font-size:14px;line-height:1.55;color:#1f1f1f">
${text.split('\n').map(l => l.trim() ? `<p style="margin:0 0 12px">${escapeHtml(l)}</p>` : '').join('')}
</div>`;
}

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function generate({ industry = 'saas', recipient, sender, htmlMode = true }) {
  const bank = industries[industry] || industries.saas;
  const ctx = buildContext(recipient, sender, industry);

  const subject = fill(pick(bank.subjects), ctx);
  const text = [
    fill(pick(bank.openers), ctx),
    '',
    fill(pick(bank.bodies), ctx),
    fill(pick(bank.bodies), ctx),
    '',
    fill(pick(bank.closers), ctx),
  ].join('\n');

  const html = htmlMode ? toHtml(text) : null;
  const messageId = `<${crypto.randomUUID()}@${sender.email.split('@')[1]}>`;

  return { subject, text, html, messageId, industry };
}

module.exports = { generate, listIndustries: () => Object.keys(industries) };