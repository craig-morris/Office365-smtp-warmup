require('dotenv').config();

module.exports = {
  port: Number(process.env.PORT || 4000),
  publicBaseUrl: process.env.PUBLIC_BASE_URL || 'http://localhost:4000',
  unsubSecret: process.env.UNSUB_SECRET || 'change-me',
  senderAddress: process.env.SENDER_ADDRESS || '123 Example St, Wilmington DE 19801',
  smtp: {
    host: process.env.SMTP_HOST || '',
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || 'false') === 'true',
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
  },
  imap: {
    host: process.env.IMAP_HOST || '',
    port: Number(process.env.IMAP_PORT || 993),
    user: process.env.IMAP_USER || '',
    pass: process.env.IMAP_PASS || '',
  },
  listUnsubMail: process.env.LIST_UNSUB_MAIL || 'unsubscribe@example.com',
  listUnsubUrl: process.env.LIST_UNSUB_URL || 'https://example.com/unsubscribe',
  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN || '',
    chatId: process.env.TELEGRAM_CHAT_ID || '',
  },
};