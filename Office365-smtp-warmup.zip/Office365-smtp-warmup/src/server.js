const express = require('express');
const path = require('path');
const config = require('./config');
const log = require('./utils/logger');

const app = express();
app.use(express.json({ limit: '4mb' }));
app.use(express.urlencoded({ extended: false })); // for one-click unsub POST
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/reports', express.static(path.join(__dirname, '..', 'reports')));

app.use('/api/campaigns', require('./routes/campaigns'));
app.use('/api/reports',   require('./routes/reports'));
app.use('/api/content',   require('./routes/content'));
app.use('/unsubscribe',   require('./routes/unsubscribe'));

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.listen(config.port, () => {
  log.info(`SMTP Warmup listening on http://localhost:${config.port}`);
});